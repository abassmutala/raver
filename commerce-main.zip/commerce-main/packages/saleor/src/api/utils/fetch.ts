import zeitFetch from '@vercel/fetch'
export default zeitFetch()
