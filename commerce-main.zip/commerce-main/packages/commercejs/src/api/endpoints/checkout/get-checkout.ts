export default function getCheckout(..._args: any[]) {
  return Promise.resolve({ data: null })
}
